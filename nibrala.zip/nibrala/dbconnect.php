

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nibrala";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


} catch (Exception $e) {
    echo "cannot connect";
}
?>

<?php
try{
    $pepe = new mysqli("localhost","root","","nibrala");
} catch (Exception $e){
    $error = "niet goed";
    die($error);
}?>

