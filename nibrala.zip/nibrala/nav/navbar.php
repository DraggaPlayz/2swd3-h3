<?php
session_start();
?>

<!doctype html>
<html lang="nl">
<head>
    <title>Titel</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/recepten.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="../recepten/css/recepten.css">
    <style>
        header {
            width: 100%;
            background-color: rgba(80, 80, 80, 0.7);
            font-weight: bold;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background-color 0.3s ease-in-out;
        }

        .logo {
            font-size: 1.5em;
            font-weight: bold;
        }

        .navbar ul {
            list-style-type: none;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 15px;
        }

        .navbar ul li {
            margin-right: 20px;
        }

        .navbar a {
            text-decoration: none;
            color: white;
            position: relative;
            transition: color 0.3s ease-in-out;
        }

        .navbar a:hover:before {
            visibility: visible;
            transform: scaleX(1);
        }

        .admin-button {
            color: red;
        }
    </style>
</head>

<body style="background-image: url('../recepten/images/background.png'); background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">

<header>
    <div class="logo-container">
        <a href="../home foodblog/home.php"><img src="../nav/img/logo.png" alt="Logo" width="80px"></a>
    </div>
    <div class="logo">KamadoFlame</div>
    <nav class="navbar">
        <ul>
            <li><a href="../home foodblog/home.php">Home</a></li>
            <li><a href="../recepten/recepten.php">Recepten</a></li>
            <li class="nav-item">
                <a class="nav-link" href="../contact/yemen.php">Contact</a>
            </li>
            <li><a href="../recepten/kookboeken.php">Kookboeken</a></li>
            <li class="nav-item">
                <?php
                if (isset($_SESSION['user_id'])) {
                    if ($_SESSION['role'] === 'admin') {
                        echo '<a class="nav-link admin-button" href="../admin/admin.php">Admin</a>';
                    }
                    echo '<a class="nav-link" href="../profile/profile.php"><img src="../nav/img/pfp.png" width="30px"></a>';
                } else {
                    echo '<a class="nav-link" href="../login-register/login.php">Login</a>';
                }
                ?>
            </li>
        </ul>
    </nav>
</header>
