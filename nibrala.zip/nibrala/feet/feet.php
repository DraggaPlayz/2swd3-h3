
    <style>
        body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1;
        }

        footer {
            width: 100%;
            background-color: rgba(80, 80, 80, 0.7);
            color: white;
            text-align: center;
            padding: 1em;
            border-top: 2px solid #fff; 
            margin-top: auto;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer-content p {
            margin: 0;
        }

        .social-icons a {
            color: white;
            text-decoration: none;
            margin: 0 10px; 
        }

        .social-icons img {
            width: 30px;
            height: auto; 
        }
    </style>

    <footer id="footer">
        <div class="footer-content">
            <div class="footer-left">
                <p>&copy; 2023 Food Blog. All rights reserved.</p>
            </div>
            <div class="footer-right">
                <div class="social-icons">
                    <a href="https://twitter.com" target="_blank"><img src="../home foodblog/images/twitter.png" alt="Twitter"></a>
                    <a href="https://www.snapchat.com" target="_blank"><img src="../home foodblog/images/snapchat.png" alt="Snapchat"></a>
                    <a href="https://www.instagram.com" target="_blank"><img src="../home foodblog/images/instagram.png" alt="Instagram"></a>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>
