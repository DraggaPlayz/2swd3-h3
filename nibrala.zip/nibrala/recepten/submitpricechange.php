<?php
require_once "../dbconnect.php";

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve kookboek ID and new cost from the GET parameters
    $kookboekID = $_GET['kookboekID'];
    $newCost = $_GET['newCost'];

    // Update the cost in the database
    $updateSql = "UPDATE kookboeken SET cost = ? WHERE id = ?";
    $updateStmt = $pepe->prepare($updateSql);

    // Bind parameters and execute the update statement
    $updateStmt->bind_param("di", $newCost, $kookboekID);
    $updateStmt->execute();

    // Check if the update was successful
    if ($updateStmt->affected_rows > 0) {
        echo "Cost updated successfully!";
    } else {
        echo "Error updating cost: " . $updateStmt->error;
    }

    // Close the statement and the database connection
    $updateStmt->close();
    $pepe->close();

    // Redirect back to the previous page after a 2-second delay
    header("refresh:2;url=javascript://history.go(-1)");
} else {
    // If the request method is not GET, respond with an error message
    echo "Invalid request method";
}
?>
