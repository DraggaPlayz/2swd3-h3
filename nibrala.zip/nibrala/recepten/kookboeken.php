<?php
include "../nav/navbar.php";
require_once "../dbconnect.php";

// Check if the delete button is clicked
if (isset($_POST['delete_kookboek']) && isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
    $deleteKookboekID = $_POST['delete_kookboek'];

    // Delete the kookboek from the database
    $deleteSql = "DELETE FROM kookboeken WHERE id = ?";
    $deleteStmt = $pepe->prepare($deleteSql);
    $deleteStmt->bind_param("i", $deleteKookboekID);
    $deleteStmt->execute();
    $deleteStmt->close();
}

?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Kookboeken</h1>

    <div class="row">
        <?php
        // Fetch kookboeken data
        $sql = "SELECT * FROM kookboeken";
        $result = $pepe->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $kookboekID = $row['id'];
                $kookboekName = $row['kookboek_name'];
                $cost = $row['cost'];
                $link = $row['link'];

                ?>
                <div class="col-md-6">
                    <div class="card mb-4 d-flex flex-row">
                    <?php
                        if (file_exists("images/{$kookboekName}.jpg")) {
                            echo "<img src='images/{$kookboekName}.jpg' class='card-img-left' alt='$kookboekName'>";
                        } elseif (file_exists("images/{$kookboekName}.png")) {
                            echo "<img src='images/{$kookboekName}.png' class='card-img-left' alt='$kookboekName'>";
                        } else {
                            echo "<img src='images/Placeholder.jpg' class='card-img-left' alt='Placeholder Image'>";
                        }
                        ?>
                        <div class="card-body">
                            <h3 class="card-title"><?php echo $kookboekName; ?></h3>
                            <p class="card-text">
                                <?php
                                // Check if the user is admin to make the price editable
                                if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
                                    echo "Prijs: €<span contenteditable='true' data-id='{$kookboekID}' class='editable-cost' onkeydown='handleKeyPress(event)'>" . number_format($cost, 2) . "</span>";
                                } else {
                                    echo "Prijs: €" . number_format($cost, 2);
                                }
                                ?>
                            </p>
                            <p class="card-text">
                                <a href="<?php echo $link; ?>" target="_blank">
                                    <button class="btn btn-primary">Kookboek</button>
                                </a>
                            </p>

                            <?php
                            // Display delete button if logged in as admin
                            if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
                                ?>
                                <form method="post" style="margin-top: 10px;">
                                    <input type="hidden" name="delete_kookboek" value="<?php echo $kookboekID; ?>">
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<div class='col-md-12'><p>No kookboeken found</p></div>";
        }

        $pepe->close();
        ?>
    </div>
</div>

<!-- Bootstrap and Popper.js scripts (keep them at the end) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-aHTjcVzhezilmoFMefbyjbTmqQriYpwz7kuHlR8Np5uuennkJvyMwnTFcrSGjE1i" crossorigin="anonymous"></script>
<script>
    function handleKeyPress(event) {
        if (event.key === 'Enter') {
            const kookboekID = event.target.getAttribute('data-id');
            const newCost = event.target.innerText;

            // Redirect to submitpricechange.php with the updated cost
            window.location.href = `submitpricechange.php?kookboekID=${kookboekID}&newCost=${newCost}`;
        }
    }
</script>
</body>
</html>
