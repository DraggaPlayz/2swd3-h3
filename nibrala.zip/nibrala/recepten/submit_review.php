<?php
include "dbconnect.php";
session_start(); 

if (!isset($_SESSION['user_id'])) {
    header("Location: recepten.php"); 
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $user_id = $_SESSION['user_id']; 
    $recipe_id = isset($_POST['recipe_id']) ? (int)$_POST['recipe_id'] : 0;
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    $review_text = isset($_POST['review_text']) ? mysqli_real_escape_string($pepe, $_POST['review_text']) : '';


    if ($recipe_id > 0 && $rating > 0 && $review_text !== '') {
        require_once "dbconnect.php";

        $checkReviewQuery = "SELECT * FROM recipe_reviews WHERE user_id = $user_id AND recipe_id = $recipe_id";
        $checkReviewResult = $pepe->query($checkReviewQuery);

        if ($checkReviewResult && $checkReviewResult->num_rows == 0) {
            $insertReviewQuery = "INSERT INTO recipe_reviews (user_id, recipe_id, rating, review_text) VALUES ($user_id, $recipe_id, $rating, '$review_text')";
            
            if ($pepe->query($insertReviewQuery)) {
                echo "Review submitted successfully!";
            } else {
                echo "Error: " . $pepe->error;
            }
        } else {
            echo "You have already submitted a review for this recipe.";
        }

        $pepe->close();
        header("Refresh: 2; URL=recepten.php");
        exit();
    } else {
        echo "Invalid input data.";
    }
} else {
    echo "Invalid request method.";
}
?>
