<?php
include "../nav/navbar.php";
require_once "dbconnect.php"
?>
<div class="container mt-4">
    <h1 class="text-center mb-4 dogg">Heerlijke recepten voor op de BBQ</h1>

    <!-- Filter Form -->
    <form method="get">
        <div class="mb-3 filter">
            <label for="categoryFilter" class="form-label">Filter by Category:</label>
            <select id="categoryFilter" name="categoryFilter" class="form-select">
                <option value="" selected>All Categories</option>
                <?php
                // Fetching all categories
                $categoriesQuery = "SELECT * FROM categories";
                $categoriesResult = $pepe->query($categoriesQuery);

                if ($categoriesResult && $categoriesResult->num_rows > 0) {
                    while ($category = $categoriesResult->fetch_assoc()) {
                        echo "<option value='{$category['category_id']}'>{$category['category_name']}</option>";
                    }
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Apply Filter</button><br><br><br>
    </form>

    <div class="row">
        <?php
        // Check if a category filter is set
        $categoryFilter = isset($_GET['categoryFilter']) ? $_GET['categoryFilter'] : null;

        $sql = "SELECT r.recipe_id, r.recipe_name, GROUP_CONCAT(c.category_name) as recipeCategories, r.spice_level
                FROM recipes r
                LEFT JOIN recipes_categories rc ON r.recipe_id = rc.recipe_id
                LEFT JOIN categories c ON rc.category_id = c.category_id";

        // Apply category filter if selected
        if (!empty($categoryFilter)) {
            $sql .= " WHERE c.category_id = $categoryFilter";
        }

        $sql .= " GROUP BY r.recipe_id";

        $result = $pepe->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $recipeID = $row['recipe_id'];
                $recipeName = $row['recipe_name'];
                $recipeCategories = isset($row['recipeCategories']) ? $row['recipeCategories'] : 'No categories'; // Handle undefined key
                $spiceLevel = $row['spice_level'];
                $reviewsQuery = "SELECT AVG(rating) as average_rating, COUNT(*) as total_reviews FROM recipe_reviews WHERE recipe_id = $recipeID";
                $reviewsResult = $pepe->query($reviewsQuery);
                $reviewsData = $reviewsResult->fetch_assoc();
                $averageRating = $reviewsData['average_rating'];
                $totalReviews = $reviewsData['total_reviews'];

                ?>
                <div class="col-md-6">
                    <div class="card mb-4 d-flex flex-row">
                        <?php
                        if (file_exists("images/{$recipeName}.jpg")) {
                            echo "<img src='images/{$recipeName}.jpg' class='card-img-left' alt='$recipeName'>";
                        } elseif (file_exists("images/{$recipeName}.png")) {
                            echo "<img src='images/{$recipeName}.png' class='card-img-left' alt='$recipeName'>";
                        } else {
                            echo "<img src='images/placeholder.jpg' class='card-img-left' alt='Placeholder Image'>";
                        }
                        ?>
                        <div class="card-body">
                            <h3 class="card-title"><?php echo $recipeName; ?></h3>
                            <p class="card-text">
                                <?php
                                // Fetching categories for the current recipe
                                $categoriesQuery = "SELECT c.category_name
                                                    FROM recipes_categories rc
                                                    JOIN categories c ON rc.category_id = c.category_id
                                                    WHERE rc.recipe_id = $recipeID";
                                $categoriesResult = mysqli_query($pepe, $categoriesQuery);

                                // Checking if there are categories
                                if ($categoriesResult) {
                                    $categories = mysqli_fetch_all($categoriesResult, MYSQLI_ASSOC);

                                    // Displaying categories
                                    echo "Categories: ";
                                    foreach ($categories as $category) {
                                        echo $category['category_name'] . ", ";
                                    }
                                } else {
                                    echo "No categories assigned.";
                                }
                                ?>
                            </p>
                            <p class="card-text">
                                <?php
                                echo "Gemiddelde Score: " . number_format($averageRating, 1) . " ($totalReviews reviews)";
                                echo "<br>Spice Level: ";
                                $spiceImagePath = "images/spice{$spiceLevel}.png";
                                $spiceImageAlt = "Spice Level {$spiceLevel}";
                                
                                echo "<img src='{$spiceImagePath}' alt='{$spiceImageAlt}' height='1' width='1px' style='max-width: 50px;'> ";
                                ?>
                            </p>
                            <a href="recept.php?recipe_id=<?php echo $recipeID; ?>" class="btn btn-primary">Bekijk Recept</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "No recipes found";
        }

        $pepe->close();
        ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"></script>
</body>
</html>
