<style>
    body {
        color: white;
    }
    .spice-meter {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 15px;
    }

    .spice-meter img {
        max-width: 100px;
        height: auto;
        margin-right: 200px;
    }

    .spice-meter-text {
        font-weight: bold;
    }    .spice-level-image {
        text-align: center;
        background-color: white;
        border-radius: 10%;
        max-width: 100px;
        margin-right: 130px;
    }
    .spice-level-image img {
        max-width: 100px;
        height: auto;

    }
    ol{
        color: white;
    }
    p{
        color: white;
    }
</style>

<?php
include "../nav/navbar.php";
require_once "dbconnect.php";

if (isset($_GET['recipe_id'])) {
    $recipe_id = mysqli_real_escape_string($pepe, $_GET['recipe_id']);
    $sql = "SELECT r.*, GROUP_CONCAT(c.category_name) AS category_names, k.id, k.kookboek_name, k.link
        FROM recipes r
        LEFT JOIN recipes_categories rc ON r.recipe_id = rc.recipe_id
        LEFT JOIN categories c ON rc.category_id = c.category_id
        LEFT JOIN kookboeken k ON r.Kookboek = k.id
        WHERE r.recipe_id = $recipe_id";

    $result = $pepe->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $spice_level = $row['spice_level'];
?>
        <div class="container mt-4">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                <?php
                        echo "<h2 class='text-center mb-4' style='color: white;'>{$row['recipe_name']}</h2>";
                        echo "<p class='text-center'><strong>Categories:</strong> " . implode(', ', explode(',', $row['category_names'])) . "</p>";
                        ?>
                    <div class="table-wrapper">
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead class="table-dark text-center">
                                    <tr>
                                        <th class="align-middle">Ingredient</th>
                                        <th class="align-middle">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $ingredients = json_decode($row['ingredients'], true);

                                    if ($ingredients && is_array($ingredients)) {
                                        if (isset($ingredients[0]) && is_string($ingredients[0])) {
                                            $ingredientLines = explode("\r\n", $ingredients[0]);
                                            foreach ($ingredientLines as $line) {
                                                list($ingredient, $amount) = explode(":", $line, 2);

                                                $ingredient = trim($ingredient);
                                                $amount = trim($amount);

                                                echo "<tr><td>$ingredient</td><td>$amount</td></tr>";
                                            }
                                        } else {
                                            foreach ($ingredients as $ingredient => $amount) {
                                                echo "<tr><td>$ingredient</td><td>$amount</td></tr>";
                                            }
                                        }
                                    } else {
                                        echo "<tr><td colspan='2'>No ingredients found.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div><br><br>
                        <div class="spice-meter">
                            <span class="spice-meter-text" style="color: white;">Spice Level:</span>
                            <?php
                            $imagePath = "spice{$spice_level}.png";
                            $altText = "Spice {$spice_level}";
                            echo "<div class='spice-level-image'><img src='images/{$imagePath}' alt='{$altText}'></div>";
                            ?>
                        </div>
                        <p style="color: white;"><strong>Instructies:</strong></p>
                        <ol>
                            <?php
                            $instructions = preg_split('/(\d+\.\s)/', $row['instructions'], -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
                            foreach ($instructions as $index => $instruction) {
                                if ($index % 2 === 0) {
                                    echo "<li><strong>Step " . ($index / 2 + 1) . ":</strong> ";
                                } else {
                                    echo $instruction . '</li>';
                                }
                            }
                            $kookboekId = $row['id'];
                            $kookboekName = $row['kookboek_name'];
                            $link = $row['link'];
                            ?><br><br>
                            <p class="card-text">
                                <a href="<?php echo $link; ?>" target="_blank">
                                    <button class="btn btn-primary">Kookboek</button>
                                </a>
                            </p>

                            
                            <br><br>
                            <?php
                            if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                                echo "<a href='#' class='btn btn-danger' onclick='showConfirmation({$recipe_id})'>Delete Recipe</a>";
                            }

                            echo "<h3 class='mt-4' style='color: white;'>Reviews</h3>";

                            $reviewsQuery = "SELECT rr.*, u.username 
                                            FROM recipe_reviews rr
                                            JOIN users u ON rr.user_id = u.id
                                            WHERE rr.recipe_id = $recipe_id";
                            $reviewsResult = $pepe->query($reviewsQuery);

                            if ($reviewsResult && $reviewsResult->num_rows > 0) {
                                while ($review = $reviewsResult->fetch_assoc()) {
                                    echo "<p><strong>User:</strong> {$review['username']}";

                                    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                                        echo " <a href='../admin/delete_review.php?review_id={$review['review_id']}' class='btn btn-danger btn-sm'>X</a>";
                                    }

                                    echo "<br>";
                                    echo "<strong>Rating:</strong> {$review['rating']}<br>{$review['review_text']}</p>";
                                }
                            } else {
                                echo "<p>No reviews yet. Be the first to review!</p>";
                            }
                            ?>
                        </ol>
                        <form action='submit_review.php' method='POST' class="mt-4">
                            <div class="mb-3">
                                <label for='rating' class="form-label" style="color: white;">Jouw score (1-10): </label>
                                <input type='number' name='rating' min='1' max='10' class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for='review_text' class="form-label" style="color: white;">Jouw review: </label>
                                <textarea name='review_text' rows='4' class="form-control" required></textarea>
                            </div>
                            <input type='hidden' name='recipe_id' value='<?php echo $recipe_id; ?>'>
                            <input type='submit' value='Review indienen' class="btn btn-primary">
                        </form>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
<?php
    } else {
        echo "Geen recepten gevonden";
    }
} else {
    echo "Ongeldig verzoek. Geen recept-ID opgegeven.";
}
$pepe->close();
?>
<?php
include_once "../feet/feet.php";
?>
<script>
    function showConfirmation(recipeId) {
        var confirmDelete = confirm("Are you sure you want to delete this recipe?");
        if (confirmDelete) {
            window.location.href = `../admin/deleterecipe.php?recipe_id=${recipeId}`;
        }
    }
</script>