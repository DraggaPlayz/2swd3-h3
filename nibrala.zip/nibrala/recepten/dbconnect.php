<?php
try{
    $pepe = new mysqli("localhost","root","","nibrala");
} catch (Exception $e){
    $error = "probleem met verbinding van database";
    die($error);
}?>