-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2024 at 10:39 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nibrala`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'Burgers'),
(2, 'Beef'),
(3, 'Ribs'),
(4, 'Pork'),
(5, 'Chicken'),
(6, 'Vegetables'),
(7, 'Vegetarian'),
(8, 'Fish'),
(9, 'Steak');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id_contact` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `onderwerp` enum('vraag','suggestie','klacht') NOT NULL,
  `bericht` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id_contact`, `user_id`, `title`, `onderwerp`, `bericht`) VALUES
(2, 5, 'Ryzen 7 5800x', 'vraag', 'nu'),
(4, 1, 'nih', 'klacht', 'nih'),
(5, 1, 'de', 'suggestie', 'de'),
(6, 1, 'homie', 'vraag', 'In the vibrant depths of the ocean, Sharky, the tooth-brushing shark superhero, patrolled the coral reefs with a dazzling smile that could light up even the darkest abyss.\r\nArmed with a toothbrush and minty-fresh toothpaste, Sharky swam tirelessly, ensuring that all sea creatures embraced dental hygiene in their watery realm.\r\nThe underwater community admired Sharky\'s commitment to oral health, as schools of fish gathered to witness the superhero\'s daily dental demonstrations.\r\nVillainous bacteria and plaque didn\'t stand a chance against Sharky\'s relentless pursuit of clean teeth, making the ocean a safer and healthier place for all inhabitants.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `recipe_id` int(11) NOT NULL,
  `recipe_name` varchar(255) DEFAULT NULL,
  `ingredients` text DEFAULT NULL,
  `instructions` text NOT NULL,
  `spice_level` int(11) DEFAULT NULL,
  `Kookboek` varchar(255) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`recipe_id`, `recipe_name`, `ingredients`, `instructions`, `spice_level`, `Kookboek`, `image_path`) VALUES
(1, 'Classic Beef Burger', '{\n    \"Ground beef\": \"500g\",\n    \"Burger buns\": \"4\",\n    \"Lettuce\": \"1 head\",\n    \"Tomato slices\": \"2\",\n    \"Onion slices\": \"1\",\n    \"Cheese slices\": \"4\",\n    \"Salt\": \"as needed\",\n    \"Pepper\": \"as needed\"\n}', '1. Preheat the grill to medium-high heat. 2. Season ground beef with salt and pepper, shape into patties, and grill for 5-6 minutes per side. 3. Toast burger buns on the grill. 4. Assemble the burger with lettuce, tomato, onion, cheese, and desired condiments.', 2, '', NULL),
(2, 'BBQ Pork Ribs', '{\n    \"Pork ribs\": \"2 lbs\",\n    \"BBQ sauce\": \"1 cup\",\n    \"Brown sugar\": \"0.25 cup\",\n    \"Paprika\": \"1 tbsp\",\n    \"Garlic powder\": \"1 tsp\",\n    \"Salt\": \"to taste\",\n    \"Pepper\": \"to taste\"\n}', '1. Preheat the grill to low heat. 2. Season pork ribs with salt, pepper, paprika, and garlic powder. Wrap in foil and grill for 2-3 hours until tender. 3. Unwrap ribs, brush with BBQ sauce mixed with brown sugar, and grill for an additional 15-20 minutes until caramelized.', 3, '', NULL),
(3, 'Grilled Marinated Chicken', '{\n    \"Chicken breasts/thighs\": \"4 pieces\",\n    \"Olive oil\": \"0.25 cup\",\n    \"Lemon juice\": \"2 tbsp\",\n    \"Garlic (minced)\": \"2 cloves\",\n    \"Dried herbs (thyme, rosemary, oregano)\": \"1 tsp each\",\n    \"Salt\": \"to taste\",\n    \"Pepper\": \"to taste\"\n}', '1. In a bowl, mix olive oil, lemon juice, minced garlic, dried herbs, salt, and pepper. 2. Marinate chicken in the mixture for at least 30 minutes. 3. Preheat the grill to medium-high heat and grill the chicken for about 6-7 minutes per side until fully cooked.', 4, '', NULL),
(4, 'Grilled Vegetable Skewers', '{\n    \"Bell peppers\": \"2\",\n    \"Zucchini\": \"1\",\n    \"Red onion\": \"1\",\n    \"Cherry tomatoes\": \"10\",\n    \"Mushrooms\": \"8\",\n    \"Olive oil\": \"0.25 cup\",\n    \"Balsamic vinegar\": \"2 tbsp\",\n    \"Italian seasoning\": \"1 tsp\",\n    \"Salt\": \"to taste\",\n    \"Pepper\": \"to taste\"\n}', '1. Cut vegetables into chunks and thread onto skewers. 2. Mix olive oil, balsamic vinegar, Italian seasoning, salt, and pepper. 3. Brush the skewers with the mixture and grill for about 10-12 minutes, turning occasionally.', 5, '', NULL),
(8, 'homes', 'd', 'd', NULL, 'd', '../recepten/images/Screenshot 2024-01-17 111249.png'),
(9, 'blud', 'blud', 'blud', 2, 'blud', '../recepten/images/Screenshot 2024-01-17 111249.png');

-- --------------------------------------------------------

--
-- Table structure for table `recipes_categories`
--

CREATE TABLE `recipes_categories` (
  `recipe_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recipe_reviews`
--

CREATE TABLE `recipe_reviews` (
  `review_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(1) NOT NULL,
  `review_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('klant','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `role`) VALUES
(1, 'a', 'a', 'a', 'a@a', '$2y$10$SirQlclBfDdXfyG4sxDaxuGeCPNpyi3TnoDrxBTinE1kKYablNhzi', 'admin'),
(5, '3', '3', '3', '3@3', '$2y$10$k1A2GxuMmqPOA6NuP.ktC.fWH1GAqpObWOgUPFerRQnvUam7iFefC', 'klant'),
(7, 'john_doe', 'John', 'Doe', 'john.doe@email.com', '$2y$10$abc123def456', 'klant'),
(8, 'jane_smith', 'Jane', 'Smith', 'jane.smith@email.com', '$2y$10$xyz789uvw123', 'klant'),
(9, 'bob_jackson', 'Bob', 'Jackson', 'bob.jackson@email.com', '$2y$10$mno456pqr789', 'klant'),
(11, 'sam_wilson', 'Sam', 'Wilson', 'sam.wilson@email.com', '$2y$10$lmn123opq456', 'klant'),
(12, 'benbozo', 'Emilyfd', 'Brownfd', 'emily.brown@email.com', '$2y$10$123abc456def', 'klant'),
(13, 'alex_martin', 'Alex', 'Martin', 'alex.martin@email.com', '$2y$10$456xyz789uvw', 'klant'),
(15, 'david_jones', 'David', 'Jones', 'david.jones@email.com', '$2y$10$uvw456xyz789', 'klant'),
(16, 'olivia_thomas', 'Olivia', 'Thomas', 'olivia.thomas@email.com', '$2y$10$pqr123lmn456', 'klant'),
(17, '1', '1', '1', '1@1', '$2y$10$KUC3q3jb.SnldKZSfnbKi.5dMueTueF1Ze18a/DDIjOQjV7c1yL/S', 'klant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id_contact`),
  ADD KEY `linkmetuser` (`user_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`recipe_id`);

--
-- Indexes for table `recipes_categories`
--
ALTER TABLE `recipes_categories`
  ADD PRIMARY KEY (`recipe_id`,`category_id`);

--
-- Indexes for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD UNIQUE KEY `recipe_user_unique` (`recipe_id`,`user_id`),
  ADD KEY `recipe_reviews_ibfk_2` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id_contact` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `recipe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `linkmetuser` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  ADD CONSTRAINT `recipe_reviews_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `recipe_reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
