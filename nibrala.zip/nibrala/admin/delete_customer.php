<?php
include "../dbconnect.php";

// Checken of klant bestaat
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("location: admin.php");
    exit();
}

$customerId = $_GET['id'];

// Klant verwijderen van database
$deleteQuery = "DELETE FROM users WHERE id = $customerId";
mysqli_query($pepe, $deleteQuery);

header("location: admin.php");
exit();
?>
