<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // contact ID ophalen om te deleten
    $contact_id = $_POST['contact_id'];

    require_once "../dbconnect.php";

    // Delete query gebruiken
    $deleteQuery = "DELETE FROM contact WHERE id_contact = ?";
    $stmt = $pepe->prepare($deleteQuery);
    $stmt->bind_param("i", $contact_id);

    if ($stmt->execute()) {
        // Contact gedelete
        header("location: contactover.php");
        exit();
    } else {
        echo "Error deleting contact: " . $stmt->error;
    }

    $stmt->close();
    $pepe->close();
} else {
    header("location: contactover.php");
    exit();
}
?>
