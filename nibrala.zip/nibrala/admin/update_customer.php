<?php
include "../dbconnect.php";

if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    echo '<script>alert("invalid id, probeer opnieuw");</script>';
    exit();
}

$customerId = $_POST['id'];
$username = mysqli_real_escape_string($pepe, $_POST['username']);
$firstName = mysqli_real_escape_string($pepe, $_POST['first_name']);
$lastName = mysqli_real_escape_string($pepe, $_POST['last_name']);
$email = mysqli_real_escape_string($pepe, $_POST['email']);

$updateQuery = "UPDATE users 
                SET username = '$username', first_name = '$firstName', last_name = '$lastName', email = '$email' 
                WHERE id = $customerId";

$result = mysqli_query($pepe, $updateQuery);

if ($result) {
    header("location: admin.php");
    exit();
} else {
    echo "Error updating customer: " . mysqli_error($pepe);
    echo "<br>Query: $updateQuery"; 
    exit();
}
?>
