<?php
include "../nav/navbar.php";
require_once "../dbconnect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactoverzicht</title>
    <style>
        .contact-overview {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
            background-color: rgba(80, 80, 80, 0.7);
            border: 1px solid #ddd;
            padding: 10px; 
            border-radius: 5px; 
        }

        .contact-category {
            margin-bottom: 50px; 
        }

        .knopje {
            margin-left: 20px;
            max-width: 145px;
        }

        .contact-overview a.gebruiker-link {
            text-decoration: none;
        }

    </style>
</head>
<body>

<?php
$sql = "SELECT c.*, u.username
        FROM contact c
        JOIN users u ON c.user_id = u.id";
$result = $pepe->query($sql);

if ($result && $result->num_rows > 0) {
    $contacts = [
        'vraag' => [],
        'suggestie' => [],
        'klacht' => [],
    ];

    while ($row = $result->fetch_assoc()) {
        $contacts[$row['onderwerp']][] = $row;
    }
    ?>

    <div class="container mt-4 contact-overview">
        <h2 class="text-center mb-4">Contactoverzicht</h2>

        <div class="row">
            <?php foreach ($contacts as $onderwerp => $contactList) { ?>
                <div class="col-md-4 contact-category">
                    <h3 class="text-center"><?php echo ucfirst($onderwerp); ?></h3>
                    <ul>
                        <?php foreach ($contactList as $contact) { ?>
                            <li class="textdeco">
                                <strong>Titel:</strong> <?php echo $contact['title']; ?><br>
                                <strong>Gebruiker ID:</strong>
                                <?php if ($contact['user_id']) { ?>
                                    <a class="gebruiker-link" href="klantprofile.php?username=<?php echo $contact['username']; ?>">
                                        <?php echo $contact['username']; ?>
                                    </a><br>
                                <?php } else { ?>
                                    <?php echo "Geen gebruikers-ID beschikbaar"; ?><br>
                                <?php } ?>
                                <strong>Bericht:</strong> <?php echo $contact['bericht']; ?><br>

                                <form action="delete_contact.php" method="post">
                                    <input type="hidden" name="contact_id" value="<?php echo $contact['id_contact']; ?>">
                                    <button type="submit">X</button>
                                </form>

                            </li>
                            <hr>
                        <?php } ?>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </div>
    <br>
    <a class="btn btn-primary reserve-button knopje" href="admin.php">Terug naar panel</a>
    <br>

    <?php
} else {
    echo "Geen contactinformatie gevonden.";
}

$pepe->close();
include_once "../feet/feet.php";
?>

</body>
</html>
