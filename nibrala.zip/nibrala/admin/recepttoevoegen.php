<?php
include "../dbconnect.php"; 
include "../nav/navbar.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form data retrieval
    $recipe_name = mysqli_real_escape_string($pepe, $_POST['recipe_name']);
    $ingredients = $_POST['ingredients'];
    $instructions = mysqli_real_escape_string($pepe, $_POST['instructions']);
    $kookboek = mysqli_real_escape_string($pepe, $_POST['kookboek']);
    $spice_level = mysqli_real_escape_string($pepe, $_POST['spice_level']);
    $categories = isset($_POST['categories']) ? $_POST['categories'] : [];

    $errors = [];
    if (empty($recipe_name) || empty($ingredients) || empty($instructions) || empty($kookboek) || empty($spice_level) || empty($categories)) {
        $errors[] = "Recipe name, ingredients, instructions, cookbook, spice level, and categories are required.";
    }

    if (empty($errors)) {
        // Image upload
        $image_path = null;
        if ($_FILES['recipe_image']['size'] > 0) {
            $target_dir = "../recepten/images/";
            $target_file = $target_dir . basename($_FILES['recipe_image']['name']);
            move_uploaded_file($_FILES['recipe_image']['tmp_name'], $target_file);
            $image_path = $target_file;
        }

        $ingredientLines = explode("\r\n", $ingredients);
        $formattedIngredients = [];
        foreach ($ingredientLines as $line) {
            $line = trim($line);

            if (strpos($line, ' ') !== false) {
                list($ingredient, $amount) = explode(' ', $line, 2);
            } else {
                list($ingredient, $amount) = explode(":", $line, 2);
            }

            $ingredient = trim($ingredient);
            $amount = trim($amount);
            
            $formattedIngredients[$ingredient] = $amount;
        }

        // JSON converter
        $ingredientsJson = json_encode($formattedIngredients, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        // Insert into recipes table
        $insertQuery = "INSERT INTO recipes (recipe_name, ingredients, instructions, kookboek, spice_level) 
                        VALUES ('$recipe_name', '$ingredientsJson', '$instructions', '$kookboek', '$spice_level')";
        if (mysqli_query($pepe, $insertQuery)) {
            // Get the recipe_id of the inserted recipe
            $recipe_id = mysqli_insert_id($pepe);

            // Insert into recipes_categories table for each selected category
            foreach ($categories as $category_id) {
                $category_id = mysqli_real_escape_string($pepe, $category_id);
                $categoryInsertQuery = "INSERT INTO recipes_categories (recipe_id, category_id) 
                                       VALUES ('$recipe_id', '$category_id')";
                mysqli_query($pepe, $categoryInsertQuery);
            }

            header("location: ../recepten/recepten.php");
            exit();
        } else {
            echo "Error adding recipe: " . mysqli_error($pepe);
        }
    } else {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Recipe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="css/recepten.css">
    <style>
        body {
            color: white;
        }
        .container {
            background-color: rgba(80,80,80,0.7);
            border: 1px solid #ccc;
            padding: 20px;
            width: 50%;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <br><br>
    <div class="container">
        <h2>Add Recipe</h2>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
            <label for="recipe_name">Recipe Name:</label>
            <input type="text" id="recipe_name" name="recipe_name" required><br><br>

            <label>Categories:</label><br>
            <?php
            $categoriesQuery = "SELECT * FROM categories";
            $categoriesResult = mysqli_query($pepe, $categoriesQuery);
            while ($category = mysqli_fetch_assoc($categoriesResult)) {
                echo "<label><input type='checkbox' name='categories[]' value='{$category['category_id']}'> {$category['category_name']}</label><br>";
            }
            ?><br>

            <label for="ingredients">Ingredients:</label><br>
            <textarea id="ingredients" name="ingredients" rows="4" cols="50" required></textarea><br>

            <label for="instructions">Instructions:</label><br>
            <textarea id="instructions" name="instructions" rows="4" cols="50" required></textarea><br>

            <label for="kookboek">Cookbook:</label>
            <select id="kookboek" name="kookboek" required>
                <?php
                $kookboekenQuery = "SELECT * FROM kookboeken";
                $kookboekenResult = mysqli_query($pepe, $kookboekenQuery);
                while ($kookboekOption = mysqli_fetch_assoc($kookboekenResult)) {
                    echo "<option value='{$kookboekOption['id']}'>{$kookboekOption['kookboek_name']}</option>";
                }
                ?>
            </select><br>

            <label for="spice_level">Spice Level:</label>
            <select id="spice_level" name="spice_level" required>
                <option value="1">Very Mild</option>
                <option value="2">Mild</option>
                <option value="3">Moderate</option>
                <option value="4">Spicy</option>
                <option value="5">Very Spicy</option>
            </select><br><br>

            <label for="recipe_image">Recipe Image:</label>
            <input type="file" id="recipe_image" name="recipe_image"><br><br>

            <input class="btn btn-primary reserve-button" type="submit" value="Add Recipe"><br><br>
        </form>

        <a class="btn btn-primary reserve-button ene" href="../recepten/recepten.php">Back to Customer List</a>
    </div>
</body>
</html>

<?php
mysqli_close($pepe);
?>
<br><br>
<?php
include_once "../feet/feet.php" 
?>
