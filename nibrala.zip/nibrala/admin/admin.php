<?php
include "../dbconnect.php"; 
include "../nav/navbar.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login-register/login.php");
    exit(); 
}

// data ophalen
function klanten($pepe) {
    $allInfo = "SELECT * FROM users WHERE role = 'klant' ORDER BY last_name, first_name";
    $result = $pepe->query($allInfo);
    return $result->fetch_all(MYSQLI_ASSOC);
}

try {
    

    // klanten removen
    if (isset($_POST['remove_customers'])) {
        if (isset($_POST['selected_customers'])) {
            $selectedCustomers = $_POST['selected_customers'];
            foreach ($selectedCustomers as $customerId) {
                $deleteQuery = "DELETE FROM users WHERE id = $customerId";
                mysqli_query($pepe, $deleteQuery);
            }
            header("Location: admin.php");
            exit();
        }
    }

    // Zoek functionaliteit
    if (isset($_POST['search_customers'])) {
        $searchKeyword = mysqli_real_escape_string($pepe, $_POST['search']);
        $searchQuery = "SELECT * FROM users WHERE (first_name LIKE '%$searchKeyword%' OR last_name LIKE '%$searchKeyword%' OR username LIKE '%$searchKeyword%') AND role = 'klant' ORDER BY last_name, first_name";
        $result = mysqli_query($pepe, $searchQuery);
        $customers = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        $customers = klanten($pepe);
    }

    
    if (isset($_POST['reset_search'])) {
        $customers = klanten($pepe);
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klantenmanagement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="admin.css">
</head>

<body>
        <div class="customer-list">
            <h2>Klantenlijst</h2>
            <div class="search-bar">
                <form action="admin.php" method="POST">
                    <label for="search">Zoeken:</label>
                    <input type="text" id="search" name="search"> <br> <br>
                    <input type="submit"class="btn btn-primary reserve-button" value="Search" name="search_customers">
                    <input type="submit"class="btn btn-primary reserve-button" value="Reset" name="reset_search">
                    <br> <br>
                </form>
            </div>

            <form action="admin.php" method="POST">
            <ul>
                <?php
foreach ($customers as $customer) {
    echo "<li>
            <input type='checkbox' name='selected_customers[]' value='{$customer['id']}'> &nbsp; 
            <a href='klantprofile.php?id={$customer['id']}' style='text-decoration: none;'>
                {$customer['first_name']} {$customer['last_name']} ({$customer['username']})
            </a>
          </li>";
}
                ?>
            </ul>

                <div class="form-group">
                <input type="submit"class="btn btn-primary reserve-button" value="Verwijder Klant" name="remove_customers">
                </div>
            </form>
        </div>
    </div>
    <br> <br>
    <a class="btn btn-primary reserve-button links ene" href="../home foodblog/home.php">Ga naar Home</a>
    <a class="btn btn-primary reserve-button links" href="recepttoevoegen.php">Product Toevoegen</a>
    <a class="btn btn-primary reserve-button links onder" href="contactover.php">Contact Informatie</a>
    <a class="btn btn-primary reserve-button links boven" href="kookboektoevoegen.php">Kookboek Toevoegen</a>
    <?php include "../feet/feet.php"?>
</body>

</html>
