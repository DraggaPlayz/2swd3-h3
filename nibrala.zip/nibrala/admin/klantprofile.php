<?php
include "../dbconnect.php";
include "../nav/navbar.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("location: admin.php");
    exit();
}

$customerId = $_GET['id'];

// Klanteninformatie ophalen uit database
$query = "SELECT * FROM users WHERE id = $customerId";
$result = $pepe->query($query);

// checken of klant bestaat
if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
} else {
    header("location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<style>

.ehh {

     
        border: 1px solid #ccc;
        color: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: rgba(80, 80, 80, 0.7);
        max-width: 400px;
        margin: 0 auto;
        margin-top: 20px;
    }


    .ene {
  position: fixed;
  bottom: 50px;
  left: 10px;
  margin-bottom: 20px;
}

</style>
</head>

<body>
    <div class="customer-profile ehh">
        <h2>Customer Profile</h2>

        <form action="update_customer.php" class="forum" method="POST">
            <div class="profile-info">
            <input type="hidden" name="id" value="<?php echo $customer['id']; ?>">
                <p><strong>ID:</strong> <?php echo $customer['id']; ?></p>
                <p><strong>Username:</strong> <input type="text" name="username" value="<?php echo $customer['username']; ?>"></p>
                <p><strong>First Name:</strong> <input type="text" name="first_name" value="<?php echo $customer['first_name']; ?>"></p>
                <p><strong>Last Name:</strong> <input type="text" name="last_name" value="<?php echo $customer['last_name']; ?>"></p>
                <p><strong>Email:</strong> <input type="text" name="email" value="<?php echo $customer['email']; ?>"></p>
            </div>

            <button type="submit" class="btn btn-primary reserve-button">Update Customer</button>
            <a href="delete_customer.php?id=<?php echo $customer['id']; ?>" class="btn btn-danger reserve-button">Delete Customer</a>
        </form>
    </div>
    <a class="btn btn-primary reserve-button ene" href="admin.php">Back to Customer List</a>
    <?php include "../feet/feet.php" ?>
</body>

</html>
