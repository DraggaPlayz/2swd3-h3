<?php
include "../dbconnect.php"; 
include "../nav/navbar.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form data retrieval
    $kookboek_name = mysqli_real_escape_string($pepe, $_POST['kookboek_name']);
    $cost = mysqli_real_escape_string($pepe, $_POST['cost']);
    $link = mysqli_real_escape_string($pepe, $_POST['link']);

    $errors = [];
    if (empty($kookboek_name) || empty($cost) || empty($link)) {
        $errors[] = "Cookbook name, cost, and link are required.";
    }

    if (empty($errors)) {
        // Insert into kookboek table
        $insertQuery = "INSERT INTO kookboeken (kookboek_name, cost, link) 
                        VALUES ('$kookboek_name', '$cost', '$link')";
        if (mysqli_query($pepe, $insertQuery)) {
            header("location: ../recepten/recepten.php");
            exit();
        } else {
            echo "Error adding cookbook: " . mysqli_error($pepe);
        }
    } else {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Cookbook</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="css/recepten.css">
    <style>
        body {
            color: white;
        }
        .container {
            background-color: rgba(80,80,80,0.7);
            border: 1px solid #ccc;
            padding: 20px;
            width: 50%;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <br><br>
    <div class="container">
        <h2>Add Cookbook</h2>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <label for="kookboek_name">Cookbook Name:</label>
            <input type="text" id="kookboek_name" name="kookboek_name" required><br><br>

            <label for="cost">Cost:</label>
            <input type="number" id="cost" name="cost" step="0.01" required><br><br>

            <label for="link">Link:</label>
            <input type="text" id="link" name="link" required><br><br>

            <input class="btn btn-primary reserve-button" type="submit" value="Add Cookbook"><br><br>
        </form>

        <a class="btn btn-primary reserve-button ene" href="../recepten/recepten.php">Back to Recipe List</a>
    </div>
</body>
</html>

<?php
mysqli_close($pepe);
?>
<br><br>
<?php
include_once "../feet/feet.php" 
?>
