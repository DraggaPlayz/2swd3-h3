<?php
include "../nav/navbar.php";
require_once "../dbconnect.php";

if (isset($_GET['recipe_id'])) {
    $recipe_id = mysqli_real_escape_string($pepe, $_GET['recipe_id']);
    
    // Check if the recipe exists
    $checkRecipeQuery = "SELECT * FROM recipes WHERE recipe_id = $recipe_id";
    $checkRecipeResult = $pepe->query($checkRecipeQuery);

    if ($checkRecipeResult->num_rows > 0) {
        // Recipe exists, proceed with deletion
        $deleteRecipeQuery = "DELETE FROM recipes WHERE recipe_id = $recipe_id";
        $deleteRecipeResult = $pepe->query($deleteRecipeQuery);

        if ($deleteRecipeResult) {
            echo "<div class='container mt-4'>";
            echo "<div class='row'>";
            echo "<div class='col-md-8 offset-md-2'>";
            echo "<div class='alert alert-success' role='alert'>";
            echo "Recipe deleted successfully!";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        } else {
            echo "<div class='container mt-4'>";
            echo "<div class='row'>";
            echo "<div class='col-md-8 offset-md-2'>";
            echo "<div class='alert alert-danger' role='alert'>";
            echo "Error deleting recipe: " . $pepe->error;
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        }
    } else {
        // Recipe doesn't exist
        echo "<div class='container mt-4'>";
        echo "<div class='row'>";
        echo "<div class='col-md-8 offset-md-2'>";
        echo "<div class='alert alert-warning' role='alert'>";
        echo "Recipe not found!";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
} else {
    // No recipe ID provided
    echo "<div class='container mt-4'>";
    echo "<div class='row'>";
    echo "<div class='col-md-8 offset-md-2'>";
    echo "<div class='alert alert-danger' role='alert'>";
    echo "Invalid request. No recipe ID provided.";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
}

$pepe->close();
include_once "../feet/feet.php";
?>
