<?php
session_start();
require_once "../dbconnect.php";

if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    if (isset($_GET['review_id'])) {
        $review_id = mysqli_real_escape_string($pepe, $_GET['review_id']);

        // Review deleten
        $deleteQuery = "DELETE FROM recipe_reviews WHERE review_id = $review_id";
        $deleteResult = $pepe->query($deleteQuery);

        if ($deleteResult) {
            // Delete succesvol
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit();
        } else {
            echo "Error: " . $pepe->error;
        }
    } else {
        echo "Invalid request. No review ID provided.";
    }
} else {
    echo "You do not have permission to delete reviews.";
}

$pepe->close();
?>
