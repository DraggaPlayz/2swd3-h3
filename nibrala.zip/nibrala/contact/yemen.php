<?php
include "../nav/navbar.php";
?>
<style>
    body {
        background-color: #f8f9fa; 
        color: white;
        margin: 0; 
        padding: 0; 
        font-family: 'Arial', sans-serif; 
    }

    .container {
        max-width: 600px; 
        margin: auto;
        padding: 20px; 
        border: 1px solid #ced4da; 
        border-radius: 8px; 
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        background-color: rgba(80, 80, 80, 0.7); 
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        margin-bottom: 8px;
    }

    input,
    select,
    textarea {
        margin-bottom: 16px;
        padding: 8px;
        border: 1px solid #ced4da; 
        border-radius: 4px;
    }

  
    textarea {
        width: 100%;
    }

    button {
        padding: 10px 15px;
        background-color: #007bff; 
        color: #fff; 
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3; 
    }

    
</style>
<div class="container">
    <form id="contactForm" action="submit.php" method="post">
        <h2>Contact</h2>
        <div class="form-group">
            <label for="name">Titel:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="options">Onderwerp:</label>
            <select id="options" name="options">
                <option value="vraag">Vraag</option>
                <option value="klacht">Klacht</option>
                <option value="suggestie">Suggestie</option>
            </select>
        </div>
        <div class="form-group">
            <label for="message">Bericht:</label><br>
            <textarea id="message" name="message" rows="3" required></textarea>
        </div>
        <button type="submit" name="submit">Submit</button>
    </form>
    <p>Geen account? <br>Neem contact op: websit@mborijnland.com <button type="button" class="btn reserve-button" onclick="copyText()">Copy</button> </p>
</div>


<script>function copyText(){navigator.clipboard.writeText("websit@mborijnland.com");}</script>

<?php
require_once "../feet/feet.php" 
?>
</body>
</html>
