<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();

    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login-register/login.php?message=login_required");
        exit();
    }

    include_once("../dbconnect.php");

    // form data ophalen
    $user_id = $_SESSION['user_id'];
    $title = $_POST['name'];
    $onderwerp = $_POST['options'];
    $bericht = $_POST['message'];

    if (empty($title) || empty($onderwerp) || empty($bericht)) {
        header("Location: your_form_page.php?error=1");
        exit();
    }

    // data in contact inserten
    $stmt = $pepe->prepare("INSERT INTO `contact` (`user_id`, `title`, `onderwerp`, `bericht`) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $title, $onderwerp, $bericht);
    $stmt->execute();

    $stmt->close();
    $pepe->close();

    header("Location: ../home foodblog/home.php");
    exit();
} else {
    header("Location: your_form_page.php");
    exit();
}
?>
