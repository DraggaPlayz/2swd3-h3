<?php
ob_start();
include "../nav/navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <style>
        .lichaam {
    font-family: Arial, sans-serif;
    background-color: rgba(255,255,254,0.7);
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin-top: 50px;
    margin-bottom: 50px;
    padding-top: 20px;
}

.registration-container {
    max-width: 300px;
    margin-bottom: 0px; 
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: rgba(80,80,80,0.7);
    box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input[type="text"],
.form-group input[type="password"],
.form-group input[type="email"] {
    width: calc(100% - 20px);
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 3px;
    margin-bottom: 10px;
}

.form-group input[type="submit"] {
    width: calc(100% - 20px);
    padding: 10px;
    font-size: 16px;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

.form-group input[type="submit"]:hover {
    background-color: #0056b3;
}

p {
    text-align: center;
    
}

p a {
     
    text-decoration: none;
}

p a:hover {
    text-decoration: underline;
}

    </style>
</head>
<?php
require_once "../dbconnect.php";

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $username = $_POST["username"];
        $password = $_POST["password"];
        $first_name = $_POST["first_name"];
        $last_name = $_POST["last_name"];
        $email = $_POST["email"];

        
        $checkQuery = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
        $checkResult = mysqli_query($pepe, $checkQuery);

        if (mysqli_num_rows($checkResult) > 0) {
            echo "Username or email is already in use!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);


            $insertQuery = "INSERT INTO users (username, password, first_name, last_name, email, role) 
                            VALUES ('$username', '$hashed_password', '$first_name', '$last_name', '$email', 'klant')";

            if (mysqli_query($pepe, $insertQuery)) {
                echo "Registration successful!";
                header("Location: login.php");
                exit();
            } else {
                echo "Error: " . $insertQuery . "<br>" . mysqli_error($pepe);
            }
        }

        
        mysqli_close($pepe);
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>


<body class="lichaam">
    <div class="registration-container">
        <h2>Registration</h2>
        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="last_name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <input class="btn btn-primary reserve-button" type="submit" value="Register">
            </div>
        </form>
        <p>Already have an account? <a href="login.php">Login Here!</a></p>
    </div>
</body>
</html>
<?php
include_once "../feet/feet.php" ;
ob_end_flush();
?>