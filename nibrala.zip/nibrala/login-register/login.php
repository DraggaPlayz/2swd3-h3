<?php
ob_start();
include "../nav/navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgba(80,80,80,0.7);
            color:white
        }
        .login-container {
            background-color: rgba(80,80,80,0.7);
            max-width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 50px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .form-group input[type="submit"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .dawg {
            color: black;
        }
        .button-container {
            display: flex;
            flex-wrap: wrap;
            align-self: center;
        }

        .dwagg{
            margin-left: 15px;
        }
        
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <input class="btn btn-primary reserve-button dawg" type="submit" value="Login">
            </div>
        </form>
        <p>Geen account?</p>
        <div class="button-container">
            <a href="register.php">
                <button class="btn btn-primary reserve-button">Register</button>
            </a>
            <p class="dwagg">     of,</p>
            <br><a href="../home foodblog/home.php">
                <button class="btn btn-primary reserve-button">Verder zonder account</button>
            </a>
        </div>
    </div>
</body>

</html>



<?php

include "../dbconnect.php";

try {

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $username = $_POST["username"];
        $password = $_POST["password"];

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($pepe, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($password, $row["password"])) {
                $_SESSION["user_id"] = $row["id"];
                $_SESSION["username"] = $row["username"];
                $_SESSION["role"] = $row["role"];

                if ($row["role"] == "admin") {
                    header("Location: ../admin/admin.php");
                } elseif ($row["role"] == "klant") {
                    header("Location: ../recepten/recepten.php");
                } else {
                    echo "Unknown role";
                }
            } else {
                echo "Incorrect password";
            }
        } else {
            echo "User not found";
        }


        mysqli_close($pepe);
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<?php
include_once "../feet/feet.php" ;
ob_end_flush();
?>