<?php include "../nav/navbar.php"; 
require_once "../recepten/dbconnect.php";
?>

<style>  
    .chicken {
    margin-left:80px
}

p {
    margin-left:60px
}
</style>
 

    <main class="homepage">
    <section class="chicken">
    <img class="foto1" src="images/bbq chicken.png" width="500">
    
</section>
<p>Welkom bij onze foodblog site. Hier kunt u alles vinden, van Italiaans tot Marokkaans.<br>Wij zijn trouw aan ons oude recepten sinds 1977. <br>U kunt al onze recepten gratis downloaden. Scroll hier verder naar beneden</p>
<div class="container mt-4">
<div class="row">
    
<?php
$sql = "SELECT r.recipe_id, r.recipe_name, GROUP_CONCAT(c.category_name) as recipeCategories, r.spice_level
FROM recipes r
LEFT JOIN recipes_categories rc ON r.recipe_id = rc.recipe_id
LEFT JOIN categories c ON rc.category_id = c.category_id";

$sql .= " GROUP BY r.recipe_id";

$result = $pepe->query($sql);

$count = 0;

if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $recipeID = $row['recipe_id'];
                $recipeName = $row['recipe_name'];
                $recipeCategories = isset($row['recipeCategories']) ? $row['recipeCategories'] : 'No categories'; // Handle undefined key
                $spiceLevel = $row['spice_level'];

                // Fetch average rating and total reviews
                $reviewsQuery = "SELECT AVG(rating) as average_rating, COUNT(*) as total_reviews FROM recipe_reviews WHERE recipe_id = $recipeID";
                $reviewsResult = $pepe->query($reviewsQuery);
                $reviewsData = $reviewsResult->fetch_assoc();
                $averageRating = $reviewsData['average_rating'];
                $totalReviews = $reviewsData['total_reviews'];

                ?>
                <div class="col-md-6">
                    <div class="card mb-4 d-flex flex-row">
                        <?php
                        if (file_exists("../recepten/images/{$recipeName}.jpg")) {
                            echo "<img src='../recepten/images/{$recipeName}.jpg' class='card-img-left' alt='$recipeName'>";
                        } elseif (file_exists("../recepten/images/{$recipeName}.png")) {
                            echo "<img src='../recepten/images/{$recipeName}.png' class='card-img-left' alt='$recipeName'>";
                        } else {
                            echo "<img src='../recepten/images/placeholder.jpg' class='card-img-left' alt='Placeholder Image'>";
                        }
                        ?>
                        <div class="card-body">
                            <h3 class="card-title"><?php echo $recipeName; ?></h3>
                            <p class="card-text">
                                <?php
                                // Fetching categories for the current recipe
                                $categoriesQuery = "SELECT c.category_name
                                                    FROM recipes_categories rc
                                                    JOIN categories c ON rc.category_id = c.category_id
                                                    WHERE rc.recipe_id = $recipeID";
                                $categoriesResult = mysqli_query($pepe, $categoriesQuery);

                                // Checking if there are categories
                                if ($categoriesResult) {
                                    $categories = mysqli_fetch_all($categoriesResult, MYSQLI_ASSOC);

                                    // Displaying categories
                                    echo "Categories: ";
                                    foreach ($categories as $category) {
                                        echo $category['category_name'] . ", ";
                                    }
                                } else {
                                    echo "No categories assigned.";
                                }
                                ?>
                            </p>
                            <p class="card-text">
                                <?php
                                echo "Average Rating: " . number_format($averageRating, 1) . " ($totalReviews reviews)";
                                echo "<br>Spice Level: ";

                                // Display spice images based on spice level
                                $spiceImagePath = "images/spice{$spiceLevel}.png";
                                $spiceImageAlt = "Spice Level {$spiceLevel}";
                                
                                echo "<img src='{$spiceImagePath}' alt='{$spiceImageAlt}' height='1' width='1px' style='max-width: 50px;'> ";
                                ?>
                            </p>
                            <a href="../recepten/recept.php?recipe_id=<?php echo $recipeID; ?>" class="btn btn-primary">Bekijk Recept</a>
                        </div>
                    </div>
                </div>
                <?php
        $count++; // Increment the counter

        if ($count >= 4) {
            break; // Exit the loop after 4 iterations
        }
    }
} else {
    echo "No recipes found";
}

        $pepe->close();
        ?>
    </div>
</div>
    </main>

    <footer id="footer">
        <div class="footer-content">
            <div class="footer-left">
                <p>&copy; 2023 Food Blog. All rights reserved.</p>
            </div>
            <div class="footer-right">
                <div class="social-icons">
                    <a href="https://twitter.com" target="_blank"><img src="images/twitter.png" width="30" alt="Twitter"></a>
                    <a href="https://www.snapchat.com" target="_blank"><img src="images/snapchat.png" width="30" alt="Snapchat"></a>
                    <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.png" width="30" alt="Instagram"></a>
                </div>
            </div>
        </div>
    </footer>
    <script>
        window.onscroll = function () {
            if (document.body.scrollTop > document.body.scrollHeight - window.innerHeight - 100 ||
                document.documentElement.scrollTop > document.documentElement.scrollHeight - window.innerHeight - 100) {
                document.getElementById('footer').style.display = 'block'; 
            } else {
                document.getElementById('footer').style.display = 'none'; 
            }
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"></script>

</body>
</html>