<?php
require_once "../dbconnect.php";
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <title>User Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    .dog {
        color:white
    }
    .profile-box {
        border: 1px solid #ccc;
        color: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: rgba(80, 80, 80, 0.7);
        max-width: 400px;
        margin: 0 auto;
        margin-top: 20px;
    }
</style>

</head>
<body>
    <?php  include "../nav/navbar.php"; ?>
    
    <div class="container mt-4">
        <h1 class="text-center mb-4 dog">Gebruikersprofiel</h1>

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="profile-box">
                    <?php
                    $userId = $_SESSION['user_id'];
                    $sql = "SELECT * FROM users WHERE id = $userId"; 
                    $result = $pepe->query($sql);
        
                    if ($result->num_rows > 0) {
                        $userData = $result->fetch_assoc();
                        echo "<p>Voornaam: " . $userData['first_name'] . "</p>";
                        echo "<p>Achternaam: " . $userData['last_name'] . "</p>";
                        echo "<p>Gebruikersnaam: " . $userData['username'] . "</p>";
                        echo "<p>Email: " . $userData['email'] . "</p>";
                    } else {
                        echo "User not found.";
                    }
        
                    $pepe->close();
                    ?>
                </div>

                <form action="../login-register/logout.php" method="post" class="text-center mt-3">
                    <button type="submit" class="btn btn-danger">Uitloggen</button>
                </form>
            </div>
        </div>
    </div>
    <?php
include_once "../feet/feet.php" 
?>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>